package com.cg.cra.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.cra.dao.RegistrationDao;
import com.cg.cra.entity.Course;
import com.cg.cra.entity.Registration;

@Transactional
@Service
public class RegistrationServiceImpl implements RegistrationService {

	@Autowired
	RegistrationDao rdao;
	
	public RegistrationServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public long insertRegistration(Registration reg) {
		// TODO Auto-generated method stub
		return rdao.insertRegistration(reg);
	}

	@Override
	public List<Course> getAllCourses() {
		// TODO Auto-generated method stub
		return rdao.getAllCourses();
	}

}
