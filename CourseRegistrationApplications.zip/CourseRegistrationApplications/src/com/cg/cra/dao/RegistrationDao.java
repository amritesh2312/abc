package com.cg.cra.dao;

import java.util.List;

import com.cg.cra.entity.Course;
import com.cg.cra.entity.Registration;

public interface RegistrationDao {

	long insertRegistration(Registration reg);
	List<Course> getAllCourses();
}
